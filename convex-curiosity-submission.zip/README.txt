Convex Curiosity - Mathathon, Combinatorics

report.tex and report.pdf: the official project report.
slides.pdf: the presentation PDF.
supplementary/: website, proof walkthrough, implementation, tests, experiment data, source papers and supporting notes.

The report title block identifies the fixed repository snapshot for the supplementary files. No Lean project is submitted.

To run the website locally, serve supplementary/ with a static HTTP server and open its index.html in a browser.
For code and experiment instructions, see supplementary/workings/README.md and supplementary/research/experiments/README.md.
